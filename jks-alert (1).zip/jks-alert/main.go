package main

import (
    "fmt"
    "os"
    "time"

    "jks-alert/scheduler"
)

func main() {
    os.Setenv("JKS_DIR", "./cert")
    os.Setenv("JKS_PASSWORD", "changeit")
    os.Setenv("TEAMS_WEBHOOK", "https://your-teams-webhook")

    jksDir := os.Getenv("JKS_DIR")
    jksPassword := os.Getenv("JKS_PASSWORD")
    teamsWebhook := os.Getenv("TEAMS_WEBHOOK")

    if jksDir == "" || jksPassword == "" || teamsWebhook == "" {
        panic("missing required env vars (JKS_DIR, JKS_PASSWORD, TEAMS_WEBHOOK)")
    }

    fmt.Println("🚀 JKS expiry checker started (factory/worker architecture)...")

    for {
        fmt.Printf("\n=== Running JKS scan at %s ===\n", time.Now().Format(time.RFC1123))
        scheduler.Run(jksDir, jksPassword, teamsWebhook)
        fmt.Println("⏳ Sleeping for 24h...")
        time.Sleep(24 * time.Hour)
    }
}
