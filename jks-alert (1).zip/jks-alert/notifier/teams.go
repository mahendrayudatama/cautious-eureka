package notifier

import (
    "bytes"
    "encoding/json"
    "fmt"
    "net/http"
    "path/filepath"

    "jks-alert/worker"
)

func SendTeamsAlert(webhook string, results []worker.Result) error {
    var alerts []map[string]string
    for _, r := range results {
        if r.Alert {
            msg := fmt.Sprintf("⚠️ JKS `%s` will expire on %s",
                filepath.Base(r.Path),
                r.Expiry.Format("2006-01-02"),
            )
            alerts = append(alerts, map[string]string{"text": msg})
        }
    }

    if len(alerts) == 0 {
        return nil
    }

    body := map[string]interface{}{
        "alerts": alerts,
    }
    jsonBody, _ := json.Marshal(body)

    resp, err := http.Post(webhook, "application/json", bytes.NewBuffer(jsonBody))
    if err != nil {
        return err
    }
    defer resp.Body.Close()

    fmt.Printf("📢 Sent %d alerts\n", len(alerts))
    return nil
}
