package checker

import (
    "bytes"
    "fmt"
    "os/exec"
    "regexp"
    "strings"
    "time"
)

func CheckJKSExpiry(path string, password string) (time.Time, error) {
    cmd := exec.Command("keytool", "-list", "-v", "-keystore", path, "-storepass", password)
    var out bytes.Buffer
    cmd.Stdout = &out
    cmd.Stderr = &out
    err := cmd.Run()
    if err != nil {
        return time.Time{}, fmt.Errorf("failed running keytool: %v, output: %s", err, out.String())
    }

    re := regexp.MustCompile(`until:\s*(.*)`)
    match := re.FindStringSubmatch(out.String())
    if len(match) < 2 {
        return time.Time{}, fmt.Errorf("could not parse expiry")
    }

    expiryStr := strings.TrimSpace(match[1])
    layout := "Mon Jan 2 15:04:05 MST 2006"
    return time.Parse(layout, expiryStr)
}
