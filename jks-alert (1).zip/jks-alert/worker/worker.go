package worker

import (
    "context"
    "sync"
    "time"

    "jks-alert/checker"
)

type Task struct {
    Path string
}

type Result struct {
    Path   string
    Expiry time.Time
    Alert  bool
    Err    error
}

func Worker(ctx context.Context, id int, jobs <-chan Task, results chan<- Result, wg *sync.WaitGroup, jksPassword string) {
    defer wg.Done()
    for {
        select {
        case <-ctx.Done():
            return
        case task, ok := <-jobs:
            if !ok {
                return
            }
            expiry, err := checker.CheckJKSExpiry(task.Path, jksPassword)
            if err != nil {
                results <- Result{Path: task.Path, Err: err}
                continue
            }
            alert := time.Until(expiry) <= 7*24*time.Hour
            results <- Result{Path: task.Path, Expiry: expiry, Alert: alert}
        }
    }
}
