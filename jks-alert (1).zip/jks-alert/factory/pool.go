package factory

import (
    "context"
    "sync"

    "jks-alert/worker"
)

func NewWorkerPool(ctx context.Context, n int, jobs <-chan worker.Task, results chan<- worker.Result, jksPassword string) *sync.WaitGroup {
    var wg sync.WaitGroup
    for i := 1; i <= n; i++ {
        wg.Add(1)
        go worker.Worker(ctx, i, jobs, results, &wg, jksPassword)
    }
    return &wg
}
