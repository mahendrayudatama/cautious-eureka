package scheduler

import (
    "context"
    "fmt"
    "os"
    "path/filepath"
    "time"

    "jks-alert/factory"
    "jks-alert/notifier"
    "jks-alert/worker"
)

func Run(jksDir, jksPassword, teamsWebhook string) {
    ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
    defer cancel()

    jobs := make(chan worker.Task)
    resultsChan := make(chan worker.Result, 10)

    wg := factory.NewWorkerPool(ctx, 3, jobs, resultsChan, jksPassword)

    go func() {
        defer close(jobs)
        filepath.Walk(jksDir, func(path string, info os.FileInfo, err error) error {
            if err == nil && !info.IsDir() && filepath.Ext(path) == ".jks" {
                jobs <- worker.Task{Path: path}
            }
            return nil
        })
    }()

    go func() {
        wg.Wait()
        close(resultsChan)
    }()

    var results []worker.Result
    for r := range resultsChan {
        if r.Err != nil {
            fmt.Printf("❌ Error checking %s: %v\n", r.Path, r.Err)
        } else {
            fmt.Printf("✅ %s expires on %s\n", r.Path, r.Expiry)
        }
        results = append(results, r)
    }

    if err := notifier.SendTeamsAlert(teamsWebhook, results); err != nil {
        fmt.Printf("❌ Failed to send Teams alert: %v\n", err)
    }
}
