module minio-metrics-proxy

go 1.21

require github.com/aws/aws-sdk-go v1.55.5