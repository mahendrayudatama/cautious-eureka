package main

import (
	"io"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/aws/aws-sdk-go/aws/credentials"
	v4 "github.com/aws/aws-sdk-go/aws/signer/v4"
)

var (
	minioEndpoint = os.Getenv("MINIO_ENDPOINT")
	accessKey     = os.Getenv("MINIO_ACCESS_KEY")
	secretKey     = os.Getenv("MINIO_SECRET_KEY")
)

func metricsHandler(w http.ResponseWriter, r *http.Request) {
	req, err := http.NewRequest(
		"GET",
		minioEndpoint+"/minio/prometheus/metrics",
		nil,
	)
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	creds := credentials.NewStaticCredentials(accessKey, secretKey, "")
	signer := v4.NewSigner(creds)

	_, err = signer.Sign(req, nil, "s3", "us-east-1", time.Now())
	if err != nil {
		http.Error(w, err.Error(), 500)
		return
	}

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		http.Error(w, err.Error(), 502)
		return
	}
	defer resp.Body.Close()

	w.Header().Set("Content-Type", "text/plain")
	w.WriteHeader(resp.StatusCode)
	io.Copy(w, resp.Body)
}

func main() {
	http.HandleFunc("/metrics", metricsHandler)
	log.Println("MinIO metrics proxy running on :8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}