# MinIO Metrics Proxy (AWS SigV4)

Mini Go service untuk scraping MinIO versi lama (±2019)
yang masih butuh AWS SigV4 untuk akses metrics.

## Environment Variable
- MINIO_ENDPOINT=http://minio:9000
- MINIO_ACCESS_KEY=xxxxx
- MINIO_SECRET_KEY=xxxxx

## Run
go run main.go

## Endpoint
/metrics