package main

import (
    "bytes"
    "encoding/json"
    "fmt"
    "net/http"
    "os"
    "os/exec"
    "path/filepath"
    "regexp"
    "strings"
    "time"
)

type CertInfo struct {
    Alias  string
    Expiry time.Time
    Alert  bool
}

type Result struct {
    Path  string
    Certs []CertInfo
    Err   error
}

func checkJKSExpiry(path string, password string) ([]CertInfo, error) {
    cmd := exec.Command("keytool", "-list", "-v", "-keystore", path, "-storepass", password)
    var out bytes.Buffer
    cmd.Stdout = &out
    cmd.Stderr = &out
    if err := cmd.Run(); err != nil {
        return nil, fmt.Errorf("failed running keytool: %v, output: %s", err, out.String())
    }

    text := out.String()
    aliasRe := regexp.MustCompile(`Alias name: (.+)`)
    untilRe := regexp.MustCompile(`Valid from: .* until: (.*)`)

    aliases := aliasRe.FindAllStringSubmatch(text, -1)
    untils := untilRe.FindAllStringSubmatch(text, -1)

    if len(aliases) != len(untils) {
        return nil, fmt.Errorf("mismatch parsing aliases and expiry dates")
    }

    var certs []CertInfo
    layout := "Mon Jan 2 15:04:05 MST 2006"
    for i := range aliases {
        expiryStr := strings.TrimSpace(untils[i][1])
        expiry, err := time.Parse(layout, expiryStr)
        if err != nil {
            return nil, fmt.Errorf("parse error: %v (input: %s)", err, expiryStr)
        }
        certs = append(certs, CertInfo{
            Alias:  strings.TrimSpace(aliases[i][1]),
            Expiry: expiry,
            Alert:  time.Until(expiry) <= 7*24*time.Hour,
        })
    }

    return certs, nil
}

func sendTeamsAlert(webhook string, results []Result) error {
    for _, r := range results {
        var alerts []string
        for _, c := range r.Certs {
            if c.Alert {
                alerts = append(alerts,
                    fmt.Sprintf("Alias `%s` in JKS `%s` will expire on %s",
                        c.Alias, filepath.Base(r.Path), c.Expiry.Format("2006-01-02")))
            }
        }
        if len(alerts) > 0 {
            msg := "⚠️ Expiring certificates:\n- " + strings.Join(alerts, "\n- ")
            body := map[string]string{"text": msg}
            jsonBody, _ := json.Marshal(body)

            _, err := http.Post(webhook, "application/json", bytes.NewBuffer(jsonBody))
            if err != nil {
                return err
            }
            fmt.Printf("📢 Sent alert for %s\n", r.Path)
        }
    }
    return nil
}

func main() {
    jksDir := os.Getenv("JKS_DIR")
    password := os.Getenv("JKS_PASSWORD")
    webhook := os.Getenv("TEAMS_WEBHOOK")

    if jksDir == "" || password == "" || webhook == "" {
        fmt.Println("❌ Missing environment variables: JKS_DIR, JKS_PASSWORD, TEAMS_WEBHOOK")
        os.Exit(1)
    }

    for {
        var results []Result
        files, _ := filepath.Glob(filepath.Join(jksDir, "*.jks"))
        for _, f := range files {
            certs, err := checkJKSExpiry(f, password)
            results = append(results, Result{Path: f, Certs: certs, Err: err})
        }

        if err := sendTeamsAlert(webhook, results); err != nil {
            fmt.Printf("❌ Error sending Teams alert: %v\n", err)
        }

        fmt.Println("✅ Scan complete. Sleeping for 24h...")
        time.Sleep(24 * time.Hour)
    }
}
