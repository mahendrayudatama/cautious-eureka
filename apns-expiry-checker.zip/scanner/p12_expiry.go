package scanner

import (
    "crypto/x509"
    "errors"
    "os"
    "time"

    "golang.org/x/crypto/pkcs12"
)

type CertInfo struct {
    NotAfter time.Time
    DaysLeft float64
}

func CheckP12Expiry(path string, password string) (*CertInfo, error) {
    data, err := os.ReadFile(path)
    if err != nil {
        return nil, err
    }

    _, cert, err := pkcs12.Decode(data, password)
    if err != nil {
        return nil, err
    }

    if cert == nil {
        return nil, errors.New("no certificate found in p12")
    }

    daysLeft := time.Until(cert.NotAfter).Hours() / 24

    return &CertInfo{
        NotAfter: cert.NotAfter,
        DaysLeft: daysLeft,
    }, nil
}
