package main

import (
    "log"
    "net/http"
    "os"
    "time"

    "apns-expiry-checker/scanner"

    "github.com/prometheus/client_golang/prometheus"
    "github.com/prometheus/client_golang/prometheus/promhttp"
)

var (
    apnsCertExpiryDays = prometheus.NewGaugeVec(
        prometheus.GaugeOpts{
            Name: "apns_cert_expiry_days",
            Help: "Days until APNs .p12 certificate expires",
        },
        []string{"cert"},
    )

    apnsCertExpiryTimestamp = prometheus.NewGaugeVec(
        prometheus.GaugeOpts{
            Name: "apns_cert_expiry_timestamp",
            Help: "APNs .p12 certificate expiry time as unix timestamp",
        },
        []string{"cert"},
    )
)

func main() {
    prometheus.MustRegister(apnsCertExpiryDays)
    prometheus.MustRegister(apnsCertExpiryTimestamp)

    certPath := os.Getenv("APNS_P12_PATH")
    if certPath == "" {
        certPath = "certs/apns.p12"
    }

    certPassword := os.Getenv("APNS_P12_PASSWORD")

    go func() {
        for {
            info, err := scanner.CheckP12Expiry(certPath, certPassword)
            if err != nil {
                log.Println("APNs cert check error:", err)
            } else {
                apnsCertExpiryDays.WithLabelValues("apns").Set(info.DaysLeft)
                apnsCertExpiryTimestamp.WithLabelValues("apns").Set(float64(info.NotAfter.Unix()))

                log.Printf(
                    "APNs expires at %s (%.2f days left)",
                    info.NotAfter.Format(time.RFC3339),
                    info.DaysLeft,
                )
            }

            time.Sleep(24 * time.Hour)
        }
    }()

    http.Handle("/metrics", promhttp.Handler())
    log.Println("APNs expiry exporter running on :8080")
    log.Fatal(http.ListenAndServe(":8080", nil))
}
