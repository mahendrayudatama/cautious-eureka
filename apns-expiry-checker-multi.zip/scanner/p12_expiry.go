package scanner

import (
    "errors"
    "os"
    "path/filepath"
    "strings"
    "time"

    "golang.org/x/crypto/pkcs12"
)

type CertInfo struct {
    Name     string
    NotAfter time.Time
    DaysLeft float64
}

func ScanP12Folder(dir string, password string) ([]CertInfo, error) {
    var results []CertInfo

    entries, err := os.ReadDir(dir)
    if err != nil {
        return nil, err
    }

    for _, e := range entries {
        if e.IsDir() || !strings.HasSuffix(e.Name(), ".p12") {
            continue
        }

        path := filepath.Join(dir, e.Name())
        data, err := os.ReadFile(path)
        if err != nil {
            continue
        }

        _, cert, err := pkcs12.Decode(data, password)
        if err != nil || cert == nil {
            continue
        }

        daysLeft := time.Until(cert.NotAfter).Hours() / 24

        results = append(results, CertInfo{
            Name:     strings.TrimSuffix(e.Name(), ".p12"),
            NotAfter: cert.NotAfter,
            DaysLeft: daysLeft,
        })
    }

    if len(results) == 0 {
        return nil, errors.New("no valid p12 certificates found")
    }

    return results, nil
}
