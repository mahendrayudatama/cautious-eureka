package main

import (
    "log"
    "net/http"
    "os"
    "time"

    "apns-expiry-checker/scanner"

    "github.com/prometheus/client_golang/prometheus"
    "github.com/prometheus/client_golang/prometheus/promhttp"
)

var (
    apnsCertExpiryDays = prometheus.NewGaugeVec(
        prometheus.GaugeOpts{
            Name: "apns_cert_expiry_days",
            Help: "Days until APNs .p12 certificate expires",
        },
        []string{"cert"},
    )

    apnsCertExpiryTimestamp = prometheus.NewGaugeVec(
        prometheus.GaugeOpts{
            Name: "apns_cert_expiry_timestamp",
            Help: "APNs .p12 certificate expiry time as unix timestamp",
        },
        []string{"cert"},
    )
)

func main() {
    prometheus.MustRegister(apnsCertExpiryDays)
    prometheus.MustRegister(apnsCertExpiryTimestamp)

    certDir := os.Getenv("APNS_CERT_DIR")
    if certDir == "" {
        certDir = "certs"
    }

    certPassword := os.Getenv("APNS_P12_PASSWORD")

    go func() {
        for {
            certs, err := scanner.ScanP12Folder(certDir, certPassword)
            if err != nil {
                log.Println("scan error:", err)
            } else {
                for _, c := range certs {
                    apnsCertExpiryDays.WithLabelValues(c.Name).Set(c.DaysLeft)
                    apnsCertExpiryTimestamp.WithLabelValues(c.Name).Set(float64(c.NotAfter.Unix()))
                    log.Printf("Cert %s expires at %s (%.2f days left)",
                        c.Name, c.NotAfter.Format(time.RFC3339), c.DaysLeft)
                }
            }
            time.Sleep(24 * time.Hour)
        }
    }()

    http.Handle("/metrics", promhttp.Handler())
    log.Println("APNs multi-cert expiry exporter running on :8080")
    log.Fatal(http.ListenAndServe(":8080", nil))
}
