module apns-expiry-checker

go 1.22

require (
    github.com/prometheus/client_golang v1.18.0
    golang.org/x/crypto v0.18.0
)
