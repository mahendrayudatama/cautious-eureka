
package main

import (
    "crypto/tls"
    "fmt"
    "io/ioutil"
    "net/http"
    "strings"
    "time"
    "github.com/prometheus/client_golang/prometheus"
    "github.com/prometheus/client_golang/prometheus/promhttp"
)

var (
    sslExpiryGauge = prometheus.NewGaugeVec(
        prometheus.GaugeOpts{
            Name: "ssl_expiry_days",
            Help: "Days left until SSL certificate expiry",
        },
        []string{"domain"},
    )

    sslCheckSuccess = prometheus.NewGaugeVec(
        prometheus.GaugeOpts{
            Name: "ssl_check_success",
            Help: "Whether SSL check succeeded (1=success, 0=failure)",
        },
        []string{"domain"},
    )

    sslLastChecked = prometheus.NewGauge(
        prometheus.GaugeOpts{
            Name: "ssl_last_checked_timestamp",
            Help: "Unix timestamp of last SSL scan",
        },
    )
)

func CheckDomain(domain string) (int, error) {
    conn, err := tls.Dial("tcp", domain+":443", &tls.Config{})
    if err != nil {
        return 0, err
    }
    defer conn.Close()

    cert := conn.ConnectionState().PeerCertificates[0]
    days := int(time.Until(cert.NotAfter).Hours() / 24)
    return days, nil
}

func main() {
    prometheus.MustRegister(sslExpiryGauge)
    prometheus.MustRegister(sslCheckSuccess)
    prometheus.MustRegister(sslLastChecked)

    domainsData, _ := ioutil.ReadFile("domains.txt")
    domains := strings.Split(strings.TrimSpace(string(domainsData)), "\n")

    go func() {
        for {
            for _, d := range domains {
                days, err := CheckDomain(d)
                if err != nil {
                    sslCheckSuccess.WithLabelValues(d).Set(0)
                } else {
                    sslExpiryGauge.WithLabelValues(d).Set(float64(days))
                    sslCheckSuccess.WithLabelValues(d).Set(1)
                }
            }
            sslLastChecked.Set(float64(time.Now().Unix()))
            time.Sleep(6 * time.Hour)
        }
    }()

    http.Handle("/metrics", promhttp.Handler())
    http.ListenAndServe(":8080", nil)
}
